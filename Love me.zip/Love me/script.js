function yes() {
    document.getElementById("response").innerText = "Thanks for accepting my proposal";
    document.getElementById("animation").innerText = "Hurray!";
    document.getElementById("animation").style.display = 'block';

    const dialogBox = document.getElementById("dialog-box");
    dialogBox.style.position = 'fixed';
    dialogBox.style.left = '50%';
    dialogBox.style.top = '50%';
    dialogBox.style.transform = 'translate(-50%, -50%)';

    // Disable buttons
    document.getElementById("yes-button").disabled = true;
    document.getElementById("no-button").disabled = true;
}

function no() {
    // Change the position of the dialog box randomly
    const dialogBox = document.getElementById("dialog-box");
    const x = Math.random() * (window.innerWidth - dialogBox.offsetWidth);
    const y = Math.random() * (window.innerHeight - dialogBox.offsetHeight);
    dialogBox.style.position = 'absolute';
    dialogBox.style.left = `${x}px`;
    dialogBox.style.top = `${y}px`;
}
